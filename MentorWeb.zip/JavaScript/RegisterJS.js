$("#Cancel").click(function(){
   window.location = "Main Page.html"; 
});

$(".RegisterField").hover(function(){
    $(this).addClass("focused");
},
    function(){
        $(this).removeClass("focused");
});

$(".RegisterField").focus(function(){
    $(".RegisterField").removeClass("inputActive");
    $(this).removeClass("focused");
    $(this).addClass("inputActive");
});

$("#Submit").click(function(){
    window.location = "PersonalProfile.html";
})

